//
//  DisplaySingleContactViewController.swift
//  ContactListDemo
//
//  Created by Nirav Joshi on 15/10/18.
//  Copyright © 2018 Nirav Joshi. All rights reserved.
//

import UIKit

class DisplaySingleContactViewController: UIViewController {

    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var lblPhoneNumber: UILabel!
    @IBOutlet weak var lblLastName: UILabel!
    @IBOutlet weak var lblFname: UILabel!
    
    
    var selectedContact = Contact()
    override func viewDidLoad() {
        super.viewDidLoad()
        lblFname.text = selectedContact.firstName
        lblLastName.text = selectedContact.lastName
        lblPhoneNumber.text = "\(selectedContact.phoneNumber)"
        lblEmail.text = selectedContact.emailID
        title = "\(selectedContact.firstName!) \(selectedContact.lastName!)'s Contact Details"
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
