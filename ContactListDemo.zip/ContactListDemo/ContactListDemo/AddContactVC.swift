//
//  AddContactVC.swift
//  ContactListDemo
//
//  Created by Nirav Joshi on 15/10/18.
//  Copyright © 2018 Nirav Joshi. All rights reserved.
//

import UIKit
import CoreData
class AddContactVC: UIViewController {
     let mainContext = AppDelegate.mainDelegate().persistentContainer.viewContext
    @IBOutlet weak var btnSave: UIButton!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtFirstName: UITextField!
    @IBOutlet weak var txtLastName: UITextField!
    @IBOutlet weak var txtPhoneNumber: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func btnSaveClick(_ sender: Any) {
//        let newContact =  Contact(entity: NSEntityDescription.entity(forEntityName: "User", in: mainContext)!, insertInto: mainContext)
//        newContact.firstName = txt.text
//        newContact.lastName = lastNameTF.text
//        newContact.emailId = emailTF.text
//        newContact.contactNumber = Int64(contactTF.text!)!
        
        let newcontact = NSEntityDescription.insertNewObject(forEntityName: "Contact", into: mainContext) as! Contact
        newcontact.firstName = txtFirstName.text
        newcontact.lastName = txtLastName.text
        newcontact.emailID = txtEmail.text
        newcontact.phoneNumber = Int64(txtPhoneNumber.text!)!
        
        do {
            try mainContext.save()
            print("saved contact")
            self.navigationController?.popViewController(animated: true)
        }
        catch
        {
            print("error in saving context")
        }
    }
    
    
}
