//
//  ViewController.swift
//  ContactListDemo
//
//  Created by Nirav Joshi on 15/10/18.
//  Copyright © 2018 Nirav Joshi. All rights reserved.
//

import UIKit
import CoreData
class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
   
    @IBOutlet weak var lblFname: UILabel!
    
    let mainContext = AppDelegate.mainDelegate().persistentContainer.viewContext
    var contactList : [Contact] = []
    var selectedContact = Contact()
    @IBOutlet weak var tblContactList: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tblContactList.rowHeight = 44.0
        tblContactList.estimatedRowHeight = UITableView.automaticDimension
        // Do any additional setup after loading the view, typically from a nib.
        
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        fetchAllContacts()
    }
    
    func fetchAllContacts() {
        let fr = NSFetchRequest<NSFetchRequestResult>(entityName: "Contact")
        contactList = try! mainContext.fetch(fr) as! [Contact]
        tblContactList.reloadData()
    }
    
    @IBAction func btnAddContactClick(_ sender: Any) {
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return contactList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ContactCell", for: indexPath) as! ContactTableCell
        cell.lblFname.text = contactList[indexPath.row].firstName
        cell.lblLname.text = contactList[indexPath.row].lastName
        cell.lblPhoneNumber.text = String(contactList[indexPath.row].phoneNumber)
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Contact")
        let predicate = NSPredicate(format: "firstName = %d", argumentArray: [contactList[indexPath.row].firstName!])
        fetchRequest.predicate = predicate
        
        do {
            let contacts = try mainContext.fetch(fetchRequest) as! [Contact]
            selectedContact = contacts.first!
            performSegue(withIdentifier: "gotoSingleContact", sender: nil)
        } catch {
            
            print("No contacts found")
        }
    }
    
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        let delete = UITableViewRowAction(style: .destructive, title: "Delete") { (action, indexPath) in
            let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Contact")
            let predicate = NSPredicate(format: "firstName = %d", argumentArray: [self.contactList[indexPath.row].firstName!])
            fetchRequest.predicate = predicate
            
            do {
                let contacts = try self.mainContext.fetch(fetchRequest) as! [Contact]
                self.contactList.remove(at: indexPath.row)
                self.mainContext.delete(contacts.first!)
                
                try! self.mainContext.save()
                self.tblContactList.reloadData()
            } catch {
                
                print("No contacts found")
            }
        }
        
        
        return [delete]
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "gotoSingleContact" {
            
            let nextVC = segue.destination as! DisplaySingleContactViewController
            nextVC.selectedContact = selectedContact
        }
    }
}
